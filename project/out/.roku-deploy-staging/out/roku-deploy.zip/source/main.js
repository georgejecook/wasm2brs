function onEvent(brsEvent) { console.log('received event', JSON.stringify(brsEvent)); try { return JSON.stringify(brsEvent); } catch (e) { return "[]"; } return ""; }
